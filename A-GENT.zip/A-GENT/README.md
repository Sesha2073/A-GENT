# A-GENT: AI-driven Genetic Exploration & Network Taxonomy

[cite_start]A-GENT is a state-of-the-art, open-source platform for the discovery and analysis of environmental DNA (eDNA), optimized for exploring the genomic "dark matter" in underexplored ecosystems like the deep sea[cite: 37].

[cite_start]This platform directly addresses the challenge of poor database representation in deep-sea eDNA analysis by using a definitive 2025 blueprint that integrates deep learning and unsupervised methods[cite: 22, 38]. [cite_start]It minimizes reliance on reference databases, enabling the discovery of novel taxa and providing deep ecological insights[cite: 25].

## Core Pipeline Stages

1.  [cite_start]**High-Fidelity Denoising**: Uses UNOISE3 and gmmDenoise for maximum signal purity[cite: 58, 59].
2.  [cite_start]**Ultra-Fast Clustering**: Employs MMseqs2 for alignment-free clustering of sequences into MOTUs.
3.  [cite_start]**AI Embedding**: Leverages Evo 2 to create deep contextual "fingerprints" of representative sequences.
4.  [cite_start]**Visualization**: Translates embeddings into interactive 2D/3D "star maps" using UMAP and Plotly.
5.  [cite_start]**Ecological Network Inference**: Constructs high-confidence networks using SparCC and other tools.
6.  [cite_start]**AI Hypothesis Generation**: Uses a Self-RAG and BioReason model to generate expert-level annotations for novel taxa[cite: 76, 77].

## Installation & Usage

1.  **Install Prerequisites**:
    - Conda (for VSEARCH, MMseqs2)
    - Ollama

2.  **Set up Environment**:
    ```bash
    # Create and activate a Python virtual environment
    python3 -m venv agent_env
    source agent_env/bin/activate

    # Install Python dependencies
    pip install -r requirements.txt
    ```

3.  **Run the Pipeline**:
    The pipeline can be executed using the main script or the Snakemake workflow.
    ```bash
    # Using the Python script
    python workflow/main.py --input_fasta data/raw/input.fasta --output_dir results/

    # Using Snakemake
    snakemake --cores 1
    ```