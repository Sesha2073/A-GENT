"""
A-GENT: Advanced Genomic Entity Network Technology

A comprehensive bioinformatics pipeline for genomic sequence analysis,
network construction, and entity clustering.
"""

__version__ = "1.0.0"
__author__ = "A-GENT Team"
__email__ = "contact@a-gent.project"

from .ingestion import *
from .feature_extraction import *
from .clustering import *
from .network_analysis import *
from .visualization import *
from .llm_engine import *