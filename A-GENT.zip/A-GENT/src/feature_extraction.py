"""
Feature extraction module for A-GENT.

Extracts various features from genomic sequences for downstream analysis.
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional, Union
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
from Bio.SeqUtils import GC, molecular_weight
from Bio.SeqUtils.ProtParam import ProteinAnalysis
from collections import Counter
import re


class SequenceFeatureExtractor:
    """Main class for extracting features from genomic sequences."""
    
    def __init__(self):
        """Initialize the feature extractor."""
        self.nucleotides = ['A', 'T', 'G', 'C']
        self.amino_acids = ['A', 'R', 'N', 'D', 'C', 'Q', 'E', 'G', 'H', 'I',
                           'L', 'K', 'M', 'F', 'P', 'S', 'T', 'W', 'Y', 'V']
    
    def extract_basic_features(self, sequence: Union[str, SeqRecord]) -> Dict:
        """
        Extract basic sequence features.
        
        Args:
            sequence: Input sequence (string or SeqRecord)
            
        Returns:
            Dictionary containing basic features
        """
        if isinstance(sequence, SeqRecord):
            seq_str = str(sequence.seq)
            seq_id = sequence.id
        else:
            seq_str = str(sequence)
            seq_id = "unknown"
        
        seq_str = seq_str.upper()
        
        features = {
            'sequence_id': seq_id,
            'length': len(seq_str),
            'gc_content': self._calculate_gc_content(seq_str),
            'at_content': self._calculate_at_content(seq_str),
            'n_content': seq_str.count('N') / len(seq_str) if len(seq_str) > 0 else 0,
            'molecular_weight': self._calculate_molecular_weight(seq_str)
        }
        
        return features
    
    def extract_nucleotide_composition(self, sequence: Union[str, SeqRecord]) -> Dict:
        """
        Extract nucleotide composition features.
        
        Args:
            sequence: Input sequence
            
        Returns:
            Dictionary containing nucleotide composition
        """
        if isinstance(sequence, SeqRecord):
            seq_str = str(sequence.seq).upper()
        else:
            seq_str = str(sequence).upper()
        
        total_length = len(seq_str)
        composition = {}
        
        # Single nucleotide frequencies
        for nucleotide in self.nucleotides:
            count = seq_str.count(nucleotide)
            composition[f'{nucleotide}_freq'] = count / total_length if total_length > 0 else 0
            composition[f'{nucleotide}_count'] = count
        
        # Dinucleotide frequencies
        for i, nt1 in enumerate(self.nucleotides):
            for j, nt2 in enumerate(self.nucleotides):
                dinuc = nt1 + nt2
                count = len(re.findall(dinuc, seq_str))
                composition[f'{dinuc}_freq'] = count / (total_length - 1) if total_length > 1 else 0
                composition[f'{dinuc}_count'] = count
        
        return composition
    
    def extract_codon_features(self, sequence: Union[str, SeqRecord], 
                              frame: int = 0) -> Dict:
        """
        Extract codon-based features.
        
        Args:
            sequence: Input sequence
            frame: Reading frame (0, 1, or 2)
            
        Returns:
            Dictionary containing codon features
        """
        if isinstance(sequence, SeqRecord):
            seq_str = str(sequence.seq).upper()
        else:
            seq_str = str(sequence).upper()
        
        # Extract codons from the specified frame
        codons = []
        for i in range(frame, len(seq_str) - 2, 3):
            codon = seq_str[i:i+3]
            if len(codon) == 3 and all(nt in 'ATGC' for nt in codon):
                codons.append(codon)
        
        features = {
            'total_codons': len(codons),
            'start_codons': sum(1 for codon in codons if codon in ['ATG']),
            'stop_codons': sum(1 for codon in codons if codon in ['TAA', 'TAG', 'TGA']),
        }
        
        # Codon usage bias
        if codons:
            codon_counts = Counter(codons)
            total_codons = len(codons)
            
            for codon, count in codon_counts.items():
                features[f'codon_{codon}_freq'] = count / total_codons
        
        return features
    
    def extract_amino_acid_features(self, sequence: Union[str, SeqRecord], 
                                   frame: int = 0) -> Dict:
        """
        Extract amino acid composition features.
        
        Args:
            sequence: Input sequence
            frame: Reading frame for translation
            
        Returns:
            Dictionary containing amino acid features
        """
        if isinstance(sequence, SeqRecord):
            seq_obj = sequence.seq
        else:
            seq_obj = Seq(sequence)
        
        try:
            # Translate sequence
            protein_seq = str(seq_obj[frame:].translate())
            
            # Remove stop codons for analysis
            protein_seq = protein_seq.replace('*', '')
            
            if not protein_seq:
                return {}
            
            # Use BioPython's ProteinAnalysis
            protein_analysis = ProteinAnalysis(protein_seq)
            
            features = {
                'protein_length': len(protein_seq),
                'molecular_weight_protein': protein_analysis.molecular_weight(),
                'aromaticity': protein_analysis.aromaticity(),
                'instability_index': protein_analysis.instability_index(),
                'isoelectric_point': protein_analysis.isoelectric_point(),
                'gravy': protein_analysis.gravy(),  # Grand average of hydropathy
            }
            
            # Amino acid composition
            aa_percent = protein_analysis.get_amino_acids_percent()
            for aa in self.amino_acids:
                features[f'aa_{aa}_freq'] = aa_percent.get(aa, 0)
            
            # Secondary structure prediction (simplified)
            sec_struct = protein_analysis.secondary_structure_fraction()
            features['helix_fraction'] = sec_struct[0]
            features['turn_fraction'] = sec_struct[1]
            features['sheet_fraction'] = sec_struct[2]
            
        except Exception as e:
            print(f"Error in amino acid analysis: {e}")
            features = {}
        
        return features
    
    def extract_repetitive_elements(self, sequence: Union[str, SeqRecord]) -> Dict:
        """
        Extract features related to repetitive elements.
        
        Args:
            sequence: Input sequence
            
        Returns:
            Dictionary containing repetitive element features
        """
        if isinstance(sequence, SeqRecord):
            seq_str = str(sequence.seq).upper()
        else:
            seq_str = str(sequence).upper()
        
        features = {}
        
        # Simple tandem repeats
        for repeat_unit_length in range(1, 7):  # 1-6 bp repeats
            for i in range(len(seq_str) - repeat_unit_length):
                unit = seq_str[i:i+repeat_unit_length]
                if all(nt in 'ATGC' for nt in unit):
                    # Count consecutive repeats
                    repeat_count = 1
                    j = i + repeat_unit_length
                    while j + repeat_unit_length <= len(seq_str):
                        if seq_str[j:j+repeat_unit_length] == unit:
                            repeat_count += 1
                            j += repeat_unit_length
                        else:
                            break
                    
                    if repeat_count >= 3:  # At least 3 consecutive repeats
                        key = f'tandem_repeat_{repeat_unit_length}bp'
                        if key not in features:
                            features[key] = 0
                        features[key] += 1
        
        # Low complexity regions (simplified)
        window_size = 50
        complexity_scores = []
        
        for i in range(0, len(seq_str) - window_size + 1, 10):
            window = seq_str[i:i+window_size]
            # Calculate Shannon entropy as complexity measure
            entropy = self._calculate_entropy(window)
            complexity_scores.append(entropy)
        
        if complexity_scores:
            features['avg_complexity'] = np.mean(complexity_scores)
            features['min_complexity'] = np.min(complexity_scores)
            features['low_complexity_regions'] = sum(1 for score in complexity_scores if score < 1.5)
        
        return features
    
    def extract_structural_features(self, sequence: Union[str, SeqRecord]) -> Dict:
        """
        Extract structural features from the sequence.
        
        Args:
            sequence: Input sequence
            
        Returns:
            Dictionary containing structural features
        """
        if isinstance(sequence, SeqRecord):
            seq_str = str(sequence.seq).upper()
        else:
            seq_str = str(sequence).upper()
        
        features = {}
        
        # CpG islands (simplified detection)
        window_size = 200
        cpg_windows = []
        
        for i in range(0, len(seq_str) - window_size + 1, 50):
            window = seq_str[i:i+window_size]
            gc_content = (window.count('G') + window.count('C')) / len(window)
            cpg_obs = window.count('CG')
            cpg_exp = (window.count('C') * window.count('G')) / len(window) if len(window) > 0 else 0
            
            if cpg_exp > 0:
                cpg_ratio = cpg_obs / cpg_exp
                if gc_content > 0.5 and cpg_ratio > 0.6 and len(window) > 199:
                    cpg_windows.append(i)
        
        features['cpg_islands'] = len(cpg_windows)
        
        # Palindromes
        palindrome_count = 0
        for length in range(4, 21, 2):  # Even lengths from 4 to 20
            for i in range(len(seq_str) - length + 1):
                substring = seq_str[i:i+length]
                reverse_complement = self._reverse_complement(substring)
                if substring == reverse_complement:
                    palindrome_count += 1
        
        features['palindromes'] = palindrome_count
        
        return features
    
    def extract_all_features(self, sequence: Union[str, SeqRecord]) -> Dict:
        """
        Extract all available features from a sequence.
        
        Args:
            sequence: Input sequence
            
        Returns:
            Dictionary containing all features
        """
        all_features = {}
        
        # Extract different feature groups
        all_features.update(self.extract_basic_features(sequence))
        all_features.update(self.extract_nucleotide_composition(sequence))
        all_features.update(self.extract_codon_features(sequence))
        all_features.update(self.extract_amino_acid_features(sequence))
        all_features.update(self.extract_repetitive_elements(sequence))
        all_features.update(self.extract_structural_features(sequence))
        
        return all_features
    
    def _calculate_gc_content(self, sequence: str) -> float:
        """Calculate GC content of a sequence."""
        if not sequence:
            return 0.0
        gc_count = sequence.count('G') + sequence.count('C')
        return gc_count / len(sequence)
    
    def _calculate_at_content(self, sequence: str) -> float:
        """Calculate AT content of a sequence."""
        if not sequence:
            return 0.0
        at_count = sequence.count('A') + sequence.count('T')
        return at_count / len(sequence)
    
    def _calculate_molecular_weight(self, sequence: str) -> float:
        """Calculate molecular weight of a DNA sequence."""
        try:
            return molecular_weight(Seq(sequence), seq_type='DNA')
        except:
            return 0.0
    
    def _calculate_entropy(self, sequence: str) -> float:
        """Calculate Shannon entropy of a sequence."""
        if not sequence:
            return 0.0
        
        # Count nucleotides
        counts = Counter(sequence)
        total = len(sequence)
        
        # Calculate entropy
        entropy = 0.0
        for count in counts.values():
            if count > 0:
                probability = count / total
                entropy -= probability * np.log2(probability)
        
        return entropy
    
    def _reverse_complement(self, sequence: str) -> str:
        """Calculate reverse complement of a DNA sequence."""
        complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}
        return ''.join(complement.get(nt, nt) for nt in sequence[::-1])


def extract_features(sequences: List[SeqRecord], 
                    feature_types: Optional[List[str]] = None) -> pd.DataFrame:
    """
    Extract features from a list of sequences.
    
    Args:
        sequences: List of SeqRecord objects
        feature_types: List of feature types to extract (default: all)
        
    Returns:
        DataFrame containing extracted features
    """
    extractor = SequenceFeatureExtractor()
    
    features_list = []
    for sequence in sequences:
        if feature_types is None:
            features = extractor.extract_all_features(sequence)
        else:
            features = {}
            if 'basic' in feature_types:
                features.update(extractor.extract_basic_features(sequence))
            if 'composition' in feature_types:
                features.update(extractor.extract_nucleotide_composition(sequence))
            if 'codon' in feature_types:
                features.update(extractor.extract_codon_features(sequence))
            if 'amino_acid' in feature_types:
                features.update(extractor.extract_amino_acid_features(sequence))
            if 'repetitive' in feature_types:
                features.update(extractor.extract_repetitive_elements(sequence))
            if 'structural' in feature_types:
                features.update(extractor.extract_structural_features(sequence))
        
        features_list.append(features)
    
    return pd.DataFrame(features_list)


if __name__ == "__main__":
    # Example usage
    from Bio.Seq import Seq
    from Bio.SeqRecord import SeqRecord
    
    # Create example sequences
    seq1 = SeqRecord(Seq("ATGCGATCGATCGATCGATCG"), id="seq1")
    seq2 = SeqRecord(Seq("GCTAGCTAGCTAGCTAGCTA"), id="seq2")
    
    sequences = [seq1, seq2]
    
    # Extract features
    feature_df = extract_features(sequences)
    print("Extracted features:")
    print(feature_df.head())