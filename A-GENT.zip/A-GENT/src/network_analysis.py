"""
Network analysis module for A-GENT.

Constructs and analyzes biological networks from genomic data.
"""

import numpy as np
import pandas as pd
import networkx as nx
from typing import List, Dict, Tuple, Optional, Union, Set
from scipy.spatial.distance import pdist, squareform
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics.pairwise import cosine_similarity, euclidean_distances
from collections import defaultdict
import matplotlib.pyplot as plt
import seaborn as sns


class BiologicalNetworkAnalyzer:
    """Main class for constructing and analyzing biological networks."""
    
    def __init__(self):
        """Initialize the network analyzer."""
        self.network = None
        self.similarity_matrix = None
        self.node_attributes = {}
        self.edge_attributes = {}
        
    def calculate_similarity_matrix(self, features: pd.DataFrame, 
                                   method: str = 'correlation',
                                   **kwargs) -> np.ndarray:
        """
        Calculate similarity matrix between sequences.
        
        Args:
            features: DataFrame containing sequence features
            method: Similarity method ('correlation', 'cosine', 'euclidean')
            **kwargs: Additional parameters for similarity calculation
            
        Returns:
            Similarity matrix
        """
        # Remove non-numeric columns
        numeric_features = features.select_dtypes(include=[np.number])
        
        # Handle missing values
        numeric_features = numeric_features.fillna(numeric_features.mean())
        
        if method == 'correlation':
            # Pearson correlation
            similarity_matrix = np.corrcoef(numeric_features.values)
        elif method == 'spearman':
            # Spearman correlation
            from scipy.stats import spearmanr
            similarity_matrix, _ = spearmanr(numeric_features.values, axis=1)
        elif method == 'cosine':
            # Cosine similarity
            similarity_matrix = cosine_similarity(numeric_features.values)
        elif method == 'euclidean':
            # Inverse euclidean distance (higher = more similar)
            distances = euclidean_distances(numeric_features.values)
            max_dist = np.max(distances)
            similarity_matrix = 1 - (distances / max_dist)
        else:
            raise ValueError(f"Unsupported similarity method: {method}")
        
        # Handle NaN values
        similarity_matrix = np.nan_to_num(similarity_matrix, nan=0.0)
        
        self.similarity_matrix = similarity_matrix
        return similarity_matrix
    
    def construct_network(self, similarity_matrix: Optional[np.ndarray] = None,
                         sequence_ids: Optional[List[str]] = None,
                         threshold: float = 0.7,
                         method: str = 'threshold') -> nx.Graph:
        """
        Construct a network from similarity matrix.
        
        Args:
            similarity_matrix: Precomputed similarity matrix
            sequence_ids: List of sequence identifiers
            threshold: Similarity threshold for edge creation
            method: Method for edge creation ('threshold', 'top_k', 'percentile')
            
        Returns:
            NetworkX graph object
        """
        if similarity_matrix is None:
            if self.similarity_matrix is None:
                raise ValueError("No similarity matrix available")
            similarity_matrix = self.similarity_matrix
        
        n_nodes = similarity_matrix.shape[0]
        
        # Create node labels
        if sequence_ids is None:
            node_labels = [f"seq_{i}" for i in range(n_nodes)]
        else:
            node_labels = sequence_ids[:n_nodes]
        
        # Create network
        self.network = nx.Graph()
        
        # Add nodes
        for i, label in enumerate(node_labels):
            self.network.add_node(label, index=i)
        
        # Add edges based on similarity
        if method == 'threshold':
            # Add edges above threshold
            for i in range(n_nodes):
                for j in range(i + 1, n_nodes):
                    similarity = similarity_matrix[i, j]
                    if similarity >= threshold:
                        self.network.add_edge(node_labels[i], node_labels[j], 
                                            weight=similarity)
        
        elif method == 'top_k':
            # Add top k edges for each node
            k = int(threshold)  # Reuse threshold parameter as k
            for i in range(n_nodes):
                similarities = similarity_matrix[i, :]
                top_indices = np.argsort(similarities)[-k-1:-1]  # Exclude self
                for j in top_indices:
                    if i != j:
                        self.network.add_edge(node_labels[i], node_labels[j],
                                            weight=similarities[j])
        
        elif method == 'percentile':
            # Add edges above percentile threshold
            percentile_threshold = np.percentile(similarity_matrix, threshold * 100)
            for i in range(n_nodes):
                for j in range(i + 1, n_nodes):
                    similarity = similarity_matrix[i, j]
                    if similarity >= percentile_threshold:
                        self.network.add_edge(node_labels[i], node_labels[j],
                                            weight=similarity)
        
        return self.network
    
    def calculate_network_metrics(self, network: Optional[nx.Graph] = None) -> Dict:
        """
        Calculate various network metrics.
        
        Args:
            network: NetworkX graph (uses self.network if None)
            
        Returns:
            Dictionary containing network metrics
        """
        if network is None:
            if self.network is None:
                raise ValueError("No network available")
            network = self.network
        
        metrics = {}
        
        # Basic metrics
        metrics['num_nodes'] = network.number_of_nodes()
        metrics['num_edges'] = network.number_of_edges()
        metrics['density'] = nx.density(network)
        
        # Connectivity
        metrics['is_connected'] = nx.is_connected(network)
        metrics['num_components'] = nx.number_connected_components(network)
        
        if metrics['is_connected']:
            metrics['diameter'] = nx.diameter(network)
            metrics['average_shortest_path_length'] = nx.average_shortest_path_length(network)
        else:
            # Calculate for largest component
            largest_cc = max(nx.connected_components(network), key=len)
            subgraph = network.subgraph(largest_cc)
            metrics['diameter'] = nx.diameter(subgraph)
            metrics['average_shortest_path_length'] = nx.average_shortest_path_length(subgraph)
        
        # Clustering
        metrics['average_clustering'] = nx.average_clustering(network)
        metrics['transitivity'] = nx.transitivity(network)
        
        # Centrality measures (for largest component if disconnected)
        if not metrics['is_connected']:
            largest_cc = max(nx.connected_components(network), key=len)
            network_for_centrality = network.subgraph(largest_cc)
        else:
            network_for_centrality = network
        
        # Average centrality measures
        degree_centrality = nx.degree_centrality(network_for_centrality)
        betweenness_centrality = nx.betweenness_centrality(network_for_centrality)
        closeness_centrality = nx.closeness_centrality(network_for_centrality)
        eigenvector_centrality = nx.eigenvector_centrality(network_for_centrality, max_iter=1000)
        
        metrics['average_degree_centrality'] = np.mean(list(degree_centrality.values()))
        metrics['average_betweenness_centrality'] = np.mean(list(betweenness_centrality.values()))
        metrics['average_closeness_centrality'] = np.mean(list(closeness_centrality.values()))
        metrics['average_eigenvector_centrality'] = np.mean(list(eigenvector_centrality.values()))
        
        return metrics
    
    def identify_communities(self, network: Optional[nx.Graph] = None,
                           method: str = 'louvain') -> Dict[str, int]:
        """
        Identify communities in the network.
        
        Args:
            network: NetworkX graph (uses self.network if None)
            method: Community detection method ('louvain', 'greedy', 'edge_betweenness')
            
        Returns:
            Dictionary mapping node IDs to community IDs
        """
        if network is None:
            if self.network is None:
                raise ValueError("No network available")
            network = self.network
        
        if method == 'louvain':
            try:
                import community as community_louvain
                partition = community_louvain.best_partition(network)
            except ImportError:
                print("python-louvain not installed, using greedy modularity")
                method = 'greedy'
        
        if method == 'greedy':
            communities = nx.community.greedy_modularity_communities(network)
            partition = {}
            for i, community in enumerate(communities):
                for node in community:
                    partition[node] = i
        
        elif method == 'edge_betweenness':
            communities = nx.community.edge_betweenness.girvan_newman(network)
            # Take the first level of division
            top_level_communities = next(communities)
            partition = {}
            for i, community in enumerate(top_level_communities):
                for node in community:
                    partition[node] = i
        
        return partition
    
    def calculate_node_metrics(self, network: Optional[nx.Graph] = None) -> pd.DataFrame:
        """
        Calculate metrics for individual nodes.
        
        Args:
            network: NetworkX graph (uses self.network if None)
            
        Returns:
            DataFrame containing node metrics
        """
        if network is None:
            if self.network is None:
                raise ValueError("No network available")
            network = self.network
        
        # Calculate centrality measures
        degree_centrality = nx.degree_centrality(network)
        betweenness_centrality = nx.betweenness_centrality(network)
        closeness_centrality = nx.closeness_centrality(network)
        
        try:
            eigenvector_centrality = nx.eigenvector_centrality(network, max_iter=1000)
        except:
            eigenvector_centrality = {node: 0 for node in network.nodes()}
        
        # Calculate clustering coefficient
        clustering_coefficient = nx.clustering(network)
        
        # Create DataFrame
        node_metrics = []
        for node in network.nodes():
            metrics = {
                'node_id': node,
                'degree': network.degree(node),
                'degree_centrality': degree_centrality[node],
                'betweenness_centrality': betweenness_centrality[node],
                'closeness_centrality': closeness_centrality[node],
                'eigenvector_centrality': eigenvector_centrality[node],
                'clustering_coefficient': clustering_coefficient[node]
            }
            node_metrics.append(metrics)
        
        return pd.DataFrame(node_metrics)
    
    def find_hub_nodes(self, network: Optional[nx.Graph] = None,
                      metric: str = 'degree_centrality',
                      top_k: int = 10) -> List[Tuple[str, float]]:
        """
        Identify hub nodes in the network.
        
        Args:
            network: NetworkX graph (uses self.network if None)
            metric: Centrality metric to use for ranking
            top_k: Number of top nodes to return
            
        Returns:
            List of (node_id, metric_value) tuples
        """
        node_metrics = self.calculate_node_metrics(network)
        
        if metric not in node_metrics.columns:
            raise ValueError(f"Metric {metric} not available")
        
        top_nodes = node_metrics.nlargest(top_k, metric)
        return list(zip(top_nodes['node_id'], top_nodes[metric]))
    
    def analyze_network_motifs(self, network: Optional[nx.Graph] = None) -> Dict:
        """
        Analyze network motifs (small subgraph patterns).
        
        Args:
            network: NetworkX graph (uses self.network if None)
            
        Returns:
            Dictionary containing motif counts
        """
        if network is None:
            if self.network is None:
                raise ValueError("No network available")
            network = self.network
        
        motif_counts = {}
        
        # Count triangles
        motif_counts['triangles'] = sum(nx.triangles(network).values()) // 3
        
        # Count 4-node motifs (simplified)
        motif_counts['4_cliques'] = sum(1 for clique in nx.find_cliques(network) if len(clique) == 4)
        
        # Count stars (nodes with degree > threshold)
        star_threshold = 5
        motif_counts['star_centers'] = sum(1 for node in network.nodes() 
                                         if network.degree(node) >= star_threshold)
        
        return motif_counts
    
    def visualize_network(self, network: Optional[nx.Graph] = None,
                         layout: str = 'spring',
                         node_color: Optional[Dict] = None,
                         figsize: Tuple[int, int] = (12, 10),
                         save_path: Optional[str] = None):
        """
        Visualize the network.
        
        Args:
            network: NetworkX graph (uses self.network if None)
            layout: Layout algorithm ('spring', 'circular', 'random', 'shell')
            node_color: Dictionary mapping nodes to colors
            figsize: Figure size
            save_path: Path to save the figure
        """
        if network is None:
            if self.network is None:
                raise ValueError("No network available")
            network = self.network
        
        plt.figure(figsize=figsize)
        
        # Choose layout
        if layout == 'spring':
            pos = nx.spring_layout(network, k=1, iterations=50)
        elif layout == 'circular':
            pos = nx.circular_layout(network)
        elif layout == 'random':
            pos = nx.random_layout(network)
        elif layout == 'shell':
            pos = nx.shell_layout(network)
        else:
            pos = nx.spring_layout(network)
        
        # Prepare node colors
        if node_color is None:
            node_colors = 'lightblue'
        else:
            node_colors = [node_color.get(node, 'lightblue') for node in network.nodes()]
        
        # Draw network
        nx.draw(network, pos, 
               node_color=node_colors,
               node_size=300,
               edge_color='gray',
               alpha=0.7,
               with_labels=True,
               font_size=8)
        
        plt.title("Biological Network Visualization")
        plt.axis('off')
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.tight_layout()
        plt.show()


def construct_similarity_network(features: pd.DataFrame,
                               sequence_ids: Optional[List[str]] = None,
                               similarity_method: str = 'correlation',
                               network_method: str = 'threshold',
                               threshold: float = 0.7) -> Tuple[nx.Graph, BiologicalNetworkAnalyzer]:
    """
    Convenience function to construct a similarity network.
    
    Args:
        features: DataFrame containing sequence features
        sequence_ids: List of sequence identifiers
        similarity_method: Method for calculating similarity
        network_method: Method for constructing network
        threshold: Threshold for edge creation
        
    Returns:
        Tuple of (network, analyzer object)
    """
    analyzer = BiologicalNetworkAnalyzer()
    
    # Calculate similarity matrix
    similarity_matrix = analyzer.calculate_similarity_matrix(features, similarity_method)
    
    # Construct network
    network = analyzer.construct_network(similarity_matrix, sequence_ids, 
                                       threshold, network_method)
    
    return network, analyzer


if __name__ == "__main__":
    # Example usage
    from sklearn.datasets import make_blobs
    
    # Create example data
    X, _ = make_blobs(n_samples=50, centers=3, n_features=10, 
                     random_state=42, cluster_std=1.0)
    
    features_df = pd.DataFrame(X, columns=[f'feature_{i}' for i in range(X.shape[1])])
    sequence_ids = [f'seq_{i}' for i in range(len(features_df))]
    
    # Construct network
    network, analyzer = construct_similarity_network(features_df, sequence_ids)
    
    # Analyze network
    metrics = analyzer.calculate_network_metrics()
    print("Network metrics:", metrics)
    
    # Find communities
    communities = analyzer.identify_communities()
    print(f"Found {len(set(communities.values()))} communities")
    
    # Visualize network
    analyzer.visualize_network()