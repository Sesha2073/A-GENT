"""
FASTA file splitting module for A-GENT.

Utilities for splitting large FASTA files into smaller chunks.
"""

import os
from pathlib import Path
from typing import List, Iterator, Optional, Union
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
import math


class FastaSplitter:
    """Class for splitting FASTA files into smaller chunks."""
    
    def __init__(self, output_dir: str = "data/processed"):
        """
        Initialize the FASTA splitter.
        
        Args:
            output_dir: Directory to save split files
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def split_by_count(self, input_file: Union[str, Path], 
                      sequences_per_file: int,
                      output_prefix: str = "chunk") -> List[str]:
        """
        Split FASTA file by number of sequences per file.
        
        Args:
            input_file: Path to input FASTA file
            sequences_per_file: Number of sequences per output file
            output_prefix: Prefix for output files
            
        Returns:
            List of output file paths
        """
        input_file = Path(input_file)
        output_files = []
        
        # Count total sequences first
        total_sequences = sum(1 for _ in SeqIO.parse(input_file, "fasta"))
        num_files = math.ceil(total_sequences / sequences_per_file)
        
        print(f"Splitting {total_sequences} sequences into {num_files} files")
        
        # Split sequences
        sequence_iterator = SeqIO.parse(input_file, "fasta")
        
        for file_num in range(num_files):
            output_file = self.output_dir / f"{output_prefix}_{file_num + 1:03d}.fasta"
            output_files.append(str(output_file))
            
            with open(output_file, 'w') as out_handle:
                sequences_written = 0
                
                for sequence in sequence_iterator:
                    SeqIO.write(sequence, out_handle, "fasta")
                    sequences_written += 1
                    
                    if sequences_written >= sequences_per_file:
                        break
            
            print(f"Written {sequences_written} sequences to {output_file}")
        
        return output_files
    
    def split_by_size(self, input_file: Union[str, Path],
                     max_file_size_mb: float,
                     output_prefix: str = "chunk") -> List[str]:
        """
        Split FASTA file by approximate file size.
        
        Args:
            input_file: Path to input FASTA file
            max_file_size_mb: Maximum size per file in MB
            output_prefix: Prefix for output files
            
        Returns:
            List of output file paths
        """
        input_file = Path(input_file)
        output_files = []
        max_size_bytes = max_file_size_mb * 1024 * 1024
        
        file_num = 1
        current_size = 0
        current_sequences = []
        
        for sequence in SeqIO.parse(input_file, "fasta"):
            # Estimate sequence size (sequence + header)
            seq_size = len(str(sequence.seq)) + len(sequence.description) + 10
            
            if current_size + seq_size > max_size_bytes and current_sequences:
                # Write current chunk
                output_file = self.output_dir / f"{output_prefix}_{file_num:03d}.fasta"
                output_files.append(str(output_file))
                
                with open(output_file, 'w') as out_handle:
                    SeqIO.write(current_sequences, out_handle, "fasta")
                
                print(f"Written {len(current_sequences)} sequences ({current_size/1024/1024:.2f} MB) to {output_file}")
                
                # Reset for next chunk
                file_num += 1
                current_sequences = []
                current_size = 0
            
            current_sequences.append(sequence)
            current_size += seq_size
        
        # Write remaining sequences
        if current_sequences:
            output_file = self.output_dir / f"{output_prefix}_{file_num:03d}.fasta"
            output_files.append(str(output_file))
            
            with open(output_file, 'w') as out_handle:
                SeqIO.write(current_sequences, out_handle, "fasta")
            
            print(f"Written {len(current_sequences)} sequences ({current_size/1024/1024:.2f} MB) to {output_file}")
        
        return output_files
    
    def split_by_length(self, input_file: Union[str, Path],
                       min_length: int = 0,
                       max_length: Optional[int] = None,
                       output_prefix: str = "length_filtered") -> List[str]:
        """
        Split FASTA file by sequence length ranges.
        
        Args:
            input_file: Path to input FASTA file
            min_length: Minimum sequence length
            max_length: Maximum sequence length (None for no limit)
            output_prefix: Prefix for output files
            
        Returns:
            List of output file paths
        """
        input_file = Path(input_file)
        output_files = []
        
        # Create length categories
        categories = []
        if min_length > 0:
            categories.append(("short", 0, min_length - 1))
        
        if max_length is not None:
            categories.append(("medium", min_length, max_length))
            categories.append(("long", max_length + 1, float('inf')))
        else:
            categories.append(("valid", min_length, float('inf')))
        
        # Initialize output files and sequences
        category_sequences = {cat[0]: [] for cat in categories}
        
        # Process sequences
        for sequence in SeqIO.parse(input_file, "fasta"):
            seq_length = len(sequence.seq)
            
            for cat_name, min_len, max_len in categories:
                if min_len <= seq_length <= max_len:
                    category_sequences[cat_name].append(sequence)
                    break
        
        # Write output files
        for cat_name, sequences in category_sequences.items():
            if sequences:
                output_file = self.output_dir / f"{output_prefix}_{cat_name}.fasta"
                output_files.append(str(output_file))
                
                with open(output_file, 'w') as out_handle:
                    SeqIO.write(sequences, out_handle, "fasta")
                
                print(f"Written {len(sequences)} {cat_name} sequences to {output_file}")
        
        return output_files
    
    def split_by_organism(self, input_file: Union[str, Path],
                         output_prefix: str = "organism") -> List[str]:
        """
        Split FASTA file by organism (based on sequence headers).
        
        Args:
            input_file: Path to input FASTA file
            output_prefix: Prefix for output files
            
        Returns:
            List of output file paths
        """
        input_file = Path(input_file)
        output_files = []
        
        # Group sequences by organism
        organism_sequences = {}
        
        for sequence in SeqIO.parse(input_file, "fasta"):
            # Try to extract organism from description
            organism = self._extract_organism(sequence.description)
            
            if organism not in organism_sequences:
                organism_sequences[organism] = []
            
            organism_sequences[organism].append(sequence)
        
        # Write output files
        for organism, sequences in organism_sequences.items():
            # Sanitize organism name for filename
            safe_organism = self._sanitize_filename(organism)
            output_file = self.output_dir / f"{output_prefix}_{safe_organism}.fasta"
            output_files.append(str(output_file))
            
            with open(output_file, 'w') as out_handle:
                SeqIO.write(sequences, out_handle, "fasta")
            
            print(f"Written {len(sequences)} sequences for {organism} to {output_file}")
        
        return output_files
    
    def merge_files(self, input_files: List[Union[str, Path]],
                   output_file: Union[str, Path]) -> int:
        """
        Merge multiple FASTA files into one.
        
        Args:
            input_files: List of input FASTA files
            output_file: Path for merged output file
            
        Returns:
            Total number of sequences merged
        """
        output_file = Path(output_file)
        total_sequences = 0
        
        with open(output_file, 'w') as out_handle:
            for input_file in input_files:
                input_file = Path(input_file)
                if input_file.exists():
                    for sequence in SeqIO.parse(input_file, "fasta"):
                        SeqIO.write(sequence, out_handle, "fasta")
                        total_sequences += 1
                else:
                    print(f"Warning: File {input_file} not found")
        
        print(f"Merged {total_sequences} sequences into {output_file}")
        return total_sequences
    
    def get_file_stats(self, file_path: Union[str, Path]) -> dict:
        """
        Get statistics for a FASTA file.
        
        Args:
            file_path: Path to FASTA file
            
        Returns:
            Dictionary containing file statistics
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            return {"error": "File not found"}
        
        sequences = list(SeqIO.parse(file_path, "fasta"))
        
        if not sequences:
            return {"sequences": 0, "total_length": 0}
        
        lengths = [len(seq.seq) for seq in sequences]
        
        stats = {
            "sequences": len(sequences),
            "total_length": sum(lengths),
            "average_length": sum(lengths) / len(lengths),
            "min_length": min(lengths),
            "max_length": max(lengths),
            "file_size_mb": file_path.stat().st_size / (1024 * 1024)
        }
        
        return stats
    
    def _extract_organism(self, description: str) -> str:
        """
        Extract organism name from sequence description.
        
        Args:
            description: Sequence description/header
            
        Returns:
            Organism name or 'unknown'
        """
        # Common patterns for organism names in FASTA headers
        patterns = [
            r'\[([^\]]+)\]$',  # [Organism name] at end
            r'OS=([^=]+?)(?:\s+[A-Z]{2}=|$)',  # UniProt format
        ]
        
        import re
        for pattern in patterns:
            match = re.search(pattern, description)
            if match:
                return match.group(1).strip()
        
        # Fallback: look for common organism indicators
        if 'homo sapiens' in description.lower():
            return 'Homo sapiens'
        elif 'escherichia coli' in description.lower():
            return 'Escherichia coli'
        elif 'mus musculus' in description.lower():
            return 'Mus musculus'
        
        return 'unknown'
    
    def _sanitize_filename(self, name: str) -> str:
        """
        Sanitize a string for use as filename.
        
        Args:
            name: Input string
            
        Returns:
            Sanitized filename
        """
        # Remove or replace problematic characters
        import re
        sanitized = re.sub(r'[^\w\-_\.]', '_', name)
        sanitized = re.sub(r'_+', '_', sanitized)  # Replace multiple underscores
        sanitized = sanitized.strip('_')
        
        return sanitized[:50]  # Limit length


def split_fasta(input_file: Union[str, Path],
               method: str = 'count',
               **kwargs) -> List[str]:
    """
    Convenience function to split FASTA files.
    
    Args:
        input_file: Path to input FASTA file
        method: Splitting method ('count', 'size', 'length', 'organism')
        **kwargs: Additional parameters for splitting method
        
    Returns:
        List of output file paths
    """
    splitter = FastaSplitter()
    
    if method == 'count':
        sequences_per_file = kwargs.get('sequences_per_file', 1000)
        return splitter.split_by_count(input_file, sequences_per_file)
    elif method == 'size':
        max_size_mb = kwargs.get('max_file_size_mb', 50)
        return splitter.split_by_size(input_file, max_size_mb)
    elif method == 'length':
        min_length = kwargs.get('min_length', 0)
        max_length = kwargs.get('max_length', None)
        return splitter.split_by_length(input_file, min_length, max_length)
    elif method == 'organism':
        return splitter.split_by_organism(input_file)
    else:
        raise ValueError(f"Unsupported splitting method: {method}")


if __name__ == "__main__":
    # Example usage
    splitter = FastaSplitter()
    
    # Example: split by count
    try:
        input_file = "data/raw/sequences.fasta"
        if Path(input_file).exists():
            output_files = splitter.split_by_count(input_file, sequences_per_file=100)
            print(f"Created {len(output_files)} files")
            
            # Get stats for each file
            for file_path in output_files:
                stats = splitter.get_file_stats(file_path)
                print(f"{file_path}: {stats}")
        else:
            print("Example input file not found. Please provide a FASTA file.")
    except Exception as e:
        print(f"Error: {e}")