"""
Visualization module for A-GENT.

Creates various plots and visualizations for genomic analysis results.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import networkx as nx
from typing import List, Dict, Tuple, Optional, Union, Any
from pathlib import Path


class GenomicVisualizer:
    """Main class for creating genomic data visualizations."""
    
    def __init__(self, style: str = 'seaborn', figsize: Tuple[int, int] = (10, 8)):
        """
        Initialize the visualizer.
        
        Args:
            style: Matplotlib style to use
            figsize: Default figure size
        """
        plt.style.use(style)
        self.figsize = figsize
        self.color_palette = sns.color_palette("husl", 10)
        
    def plot_sequence_length_distribution(self, sequences: List,
                                        bins: int = 50,
                                        title: str = "Sequence Length Distribution",
                                        save_path: Optional[str] = None) -> None:
        """
        Plot distribution of sequence lengths.
        
        Args:
            sequences: List of sequences or SeqRecord objects
            bins: Number of histogram bins
            title: Plot title
            save_path: Path to save the figure
        """
        # Extract lengths
        if hasattr(sequences[0], 'seq'):
            lengths = [len(seq.seq) for seq in sequences]
        else:
            lengths = [len(seq) for seq in sequences]
        
        plt.figure(figsize=self.figsize)
        
        # Create histogram
        plt.hist(lengths, bins=bins, alpha=0.7, color=self.color_palette[0], edgecolor='black')
        
        # Add statistics
        mean_length = np.mean(lengths)
        median_length = np.median(lengths)
        
        plt.axvline(mean_length, color='red', linestyle='--', alpha=0.8, 
                   label=f'Mean: {mean_length:.0f}')
        plt.axvline(median_length, color='orange', linestyle='--', alpha=0.8,
                   label=f'Median: {median_length:.0f}')
        
        plt.xlabel('Sequence Length (bp)')
        plt.ylabel('Frequency')
        plt.title(title)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.tight_layout()
        plt.show()
    
    def plot_gc_content_distribution(self, sequences: List,
                                   bins: int = 50,
                                   title: str = "GC Content Distribution",
                                   save_path: Optional[str] = None) -> None:
        """
        Plot distribution of GC content.
        
        Args:
            sequences: List of sequences or SeqRecord objects
            bins: Number of histogram bins
            title: Plot title
            save_path: Path to save the figure
        """
        # Calculate GC content
        gc_contents = []
        for seq in sequences:
            if hasattr(seq, 'seq'):
                seq_str = str(seq.seq).upper()
            else:
                seq_str = str(seq).upper()
            
            gc_count = seq_str.count('G') + seq_str.count('C')
            gc_content = gc_count / len(seq_str) if len(seq_str) > 0 else 0
            gc_contents.append(gc_content * 100)  # Convert to percentage
        
        plt.figure(figsize=self.figsize)
        
        # Create histogram
        plt.hist(gc_contents, bins=bins, alpha=0.7, color=self.color_palette[1], edgecolor='black')
        
        # Add statistics
        mean_gc = np.mean(gc_contents)
        median_gc = np.median(gc_contents)
        
        plt.axvline(mean_gc, color='red', linestyle='--', alpha=0.8,
                   label=f'Mean: {mean_gc:.1f}%')
        plt.axvline(median_gc, color='orange', linestyle='--', alpha=0.8,
                   label=f'Median: {median_gc:.1f}%')
        
        plt.xlabel('GC Content (%)')
        plt.ylabel('Frequency')
        plt.title(title)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.tight_layout()
        plt.show()
    
    def plot_feature_correlation_heatmap(self, features: pd.DataFrame,
                                       title: str = "Feature Correlation Heatmap",
                                       save_path: Optional[str] = None) -> None:
        """
        Plot correlation heatmap of features.
        
        Args:
            features: DataFrame containing features
            title: Plot title
            save_path: Path to save the figure
        """
        # Select only numeric columns
        numeric_features = features.select_dtypes(include=[np.number])
        
        # Calculate correlation matrix
        corr_matrix = numeric_features.corr()
        
        plt.figure(figsize=(12, 10))
        
        # Create heatmap
        mask = np.triu(np.ones_like(corr_matrix, dtype=bool))  # Mask upper triangle
        sns.heatmap(corr_matrix, mask=mask, annot=False, cmap='coolwarm', center=0,
                   square=True, linewidths=0.1, cbar_kws={"shrink": 0.8})
        
        plt.title(title)
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    def plot_pca_analysis(self, features: pd.DataFrame, labels: Optional[np.ndarray] = None,
                         n_components: int = 2,
                         title: str = "PCA Analysis",
                         save_path: Optional[str] = None) -> None:
        """
        Plot PCA analysis of features.
        
        Args:
            features: DataFrame containing features
            labels: Cluster labels for coloring
            n_components: Number of PCA components
            title: Plot title
            save_path: Path to save the figure
        """
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler
        
        # Prepare data
        numeric_features = features.select_dtypes(include=[np.number])
        numeric_features = numeric_features.fillna(numeric_features.mean())
        
        # Standardize features
        scaler = StandardScaler()
        scaled_features = scaler.fit_transform(numeric_features)
        
        # Perform PCA
        pca = PCA(n_components=n_components)
        pca_result = pca.fit_transform(scaled_features)
        
        # Create plot
        if n_components == 2:
            plt.figure(figsize=self.figsize)
            
            if labels is not None:
                unique_labels = np.unique(labels)
                colors = plt.cm.tab10(np.linspace(0, 1, len(unique_labels)))
                
                for i, label in enumerate(unique_labels):
                    mask = labels == label
                    plt.scatter(pca_result[mask, 0], pca_result[mask, 1],
                              c=[colors[i]], label=f'Cluster {label}', alpha=0.6, s=50)
                plt.legend()
            else:
                plt.scatter(pca_result[:, 0], pca_result[:, 1], 
                          c=self.color_palette[0], alpha=0.6, s=50)
            
            plt.xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.1%} variance)')
            plt.ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.1%} variance)')
            plt.title(title)
            plt.grid(True, alpha=0.3)
            
        elif n_components == 3:
            fig = plt.figure(figsize=self.figsize)
            ax = fig.add_subplot(111, projection='3d')
            
            if labels is not None:
                unique_labels = np.unique(labels)
                colors = plt.cm.tab10(np.linspace(0, 1, len(unique_labels)))
                
                for i, label in enumerate(unique_labels):
                    mask = labels == label
                    ax.scatter(pca_result[mask, 0], pca_result[mask, 1], pca_result[mask, 2],
                              c=[colors[i]], label=f'Cluster {label}', alpha=0.6, s=50)
                ax.legend()
            else:
                ax.scatter(pca_result[:, 0], pca_result[:, 1], pca_result[:, 2],
                          c=self.color_palette[0], alpha=0.6, s=50)
            
            ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.1%})')
            ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.1%})')
            ax.set_zlabel(f'PC3 ({pca.explained_variance_ratio_[2]:.1%})')
            ax.set_title(title)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.tight_layout()
        plt.show()
    
    def plot_cluster_analysis(self, features: pd.DataFrame, labels: np.ndarray,
                            title: str = "Cluster Analysis",
                            save_path: Optional[str] = None) -> None:
        """
        Plot comprehensive cluster analysis.
        
        Args:
            features: DataFrame containing features
            labels: Cluster labels
            title: Plot title
            save_path: Path to save the figure
        """
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # 1. PCA plot
        from sklearn.decomposition import PCA
        from sklearn.preprocessing import StandardScaler
        
        numeric_features = features.select_dtypes(include=[np.number])
        numeric_features = numeric_features.fillna(numeric_features.mean())
        
        scaler = StandardScaler()
        scaled_features = scaler.fit_transform(numeric_features)
        
        pca = PCA(n_components=2)
        pca_result = pca.fit_transform(scaled_features)
        
        unique_labels = np.unique(labels)
        colors = plt.cm.tab10(np.linspace(0, 1, len(unique_labels)))
        
        for i, label in enumerate(unique_labels):
            mask = labels == label
            axes[0, 0].scatter(pca_result[mask, 0], pca_result[mask, 1],
                              c=[colors[i]], label=f'Cluster {label}', alpha=0.6)
        
        axes[0, 0].set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.1%})')
        axes[0, 0].set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.1%})')
        axes[0, 0].set_title('PCA Visualization')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)
        
        # 2. Cluster size distribution
        cluster_counts = pd.Series(labels).value_counts().sort_index()
        axes[0, 1].bar(cluster_counts.index, cluster_counts.values, 
                      color=colors[:len(cluster_counts)])
        axes[0, 1].set_xlabel('Cluster ID')
        axes[0, 1].set_ylabel('Number of Sequences')
        axes[0, 1].set_title('Cluster Size Distribution')
        axes[0, 1].grid(True, alpha=0.3)
        
        # 3. Feature means by cluster
        cluster_means = []
        for label in unique_labels:
            mask = labels == label
            cluster_mean = numeric_features[mask].mean()
            cluster_means.append(cluster_mean)
        
        cluster_means_df = pd.DataFrame(cluster_means, index=unique_labels)
        
        # Select top features with highest variance
        feature_vars = cluster_means_df.var()
        top_features = feature_vars.nlargest(10).index
        
        im = axes[1, 0].imshow(cluster_means_df[top_features].T, cmap='viridis', aspect='auto')
        axes[1, 0].set_xticks(range(len(unique_labels)))
        axes[1, 0].set_xticklabels([f'C{label}' for label in unique_labels])
        axes[1, 0].set_yticks(range(len(top_features)))
        axes[1, 0].set_yticklabels(top_features, fontsize=8)
        axes[1, 0].set_xlabel('Cluster')
        axes[1, 0].set_title('Feature Means by Cluster')
        plt.colorbar(im, ax=axes[1, 0])
        
        # 4. Silhouette analysis
        from sklearn.metrics import silhouette_samples, silhouette_score
        
        silhouette_avg = silhouette_score(scaled_features, labels)
        sample_silhouette_values = silhouette_samples(scaled_features, labels)
        
        y_lower = 10
        for i, label in enumerate(unique_labels):
            cluster_silhouette_values = sample_silhouette_values[labels == label]
            cluster_silhouette_values.sort()
            
            size_cluster_i = cluster_silhouette_values.shape[0]
            y_upper = y_lower + size_cluster_i
            
            color = colors[i]
            axes[1, 1].fill_betweenx(np.arange(y_lower, y_upper),
                                    0, cluster_silhouette_values,
                                    facecolor=color, edgecolor=color, alpha=0.7)
            
            axes[1, 1].text(-0.05, y_lower + 0.5 * size_cluster_i, str(label))
            y_lower = y_upper + 10
        
        axes[1, 1].set_xlabel('Silhouette Coefficient Values')
        axes[1, 1].set_ylabel('Cluster Label')
        axes[1, 1].set_title(f'Silhouette Analysis (avg score: {silhouette_avg:.3f})')
        
        # Add vertical line for average silhouette score
        axes[1, 1].axvline(x=silhouette_avg, color="red", linestyle="--")
        
        plt.suptitle(title, fontsize=16)
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.show()
    
    def plot_network_visualization(self, network: nx.Graph,
                                 node_colors: Optional[Dict] = None,
                                 layout: str = 'spring',
                                 title: str = "Network Visualization",
                                 save_path: Optional[str] = None) -> None:
        """
        Plot network visualization.
        
        Args:
            network: NetworkX graph
            node_colors: Dictionary mapping nodes to colors
            layout: Layout algorithm
            title: Plot title
            save_path: Path to save the figure
        """
        plt.figure(figsize=(12, 10))
        
        # Choose layout
        if layout == 'spring':
            pos = nx.spring_layout(network, k=1, iterations=50)
        elif layout == 'circular':
            pos = nx.circular_layout(network)
        elif layout == 'random':
            pos = nx.random_layout(network)
        else:
            pos = nx.spring_layout(network)
        
        # Prepare node colors
        if node_colors is None:
            node_color_list = [self.color_palette[0]] * len(network.nodes())
        else:
            node_color_list = [node_colors.get(node, self.color_palette[0]) 
                             for node in network.nodes()]
        
        # Draw network
        nx.draw_networkx_nodes(network, pos, node_color=node_color_list,
                              node_size=300, alpha=0.8)
        nx.draw_networkx_edges(network, pos, edge_color='gray', alpha=0.5)
        
        # Add labels for small networks
        if len(network.nodes()) <= 50:
            nx.draw_networkx_labels(network, pos, font_size=8)
        
        plt.title(title)
        plt.axis('off')
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        plt.tight_layout()
        plt.show()
    
    def create_interactive_network(self, network: nx.Graph,
                                 node_colors: Optional[Dict] = None,
                                 title: str = "Interactive Network") -> go.Figure:
        """
        Create interactive network visualization using Plotly.
        
        Args:
            network: NetworkX graph
            node_colors: Dictionary mapping nodes to colors
            title: Plot title
            
        Returns:
            Plotly figure object
        """
        # Calculate layout
        pos = nx.spring_layout(network, k=1, iterations=50)
        
        # Prepare edge traces
        edge_x = []
        edge_y = []
        for edge in network.edges():
            x0, y0 = pos[edge[0]]
            x1, y1 = pos[edge[1]]
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])
        
        edge_trace = go.Scatter(x=edge_x, y=edge_y,
                               line=dict(width=0.5, color='#888'),
                               hoverinfo='none',
                               mode='lines')
        
        # Prepare node traces
        node_x = []
        node_y = []
        node_text = []
        node_colors_list = []
        
        for node in network.nodes():
            x, y = pos[node]
            node_x.append(x)
            node_y.append(y)
            node_text.append(str(node))
            
            if node_colors:
                node_colors_list.append(node_colors.get(node, '#888'))
            else:
                node_colors_list.append('#888')
        
        node_trace = go.Scatter(x=node_x, y=node_y,
                               mode='markers+text',
                               text=node_text,
                               textposition="middle center",
                               hoverinfo='text',
                               marker=dict(size=10,
                                         color=node_colors_list,
                                         line=dict(width=2)))
        
        # Create figure
        fig = go.Figure(data=[edge_trace, node_trace],
                       layout=go.Layout(
                           title=title,
                           titlefont_size=16,
                           showlegend=False,
                           hovermode='closest',
                           margin=dict(b=20, l=5, r=5, t=40),
                           annotations=[dict(
                               text="",
                               showarrow=False,
                               xref="paper", yref="paper",
                               x=0.005, y=-0.002,
                               xanchor="left", yanchor="bottom",
                               font=dict(color="#000", size=12)
                           )],
                           xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                           yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)))
        
        return fig


def create_genomic_report(sequences: List, features: pd.DataFrame,
                         clusters: Optional[np.ndarray] = None,
                         network: Optional[nx.Graph] = None,
                         output_dir: str = "results/reports") -> str:
    """
    Create a comprehensive genomic analysis report.
    
    Args:
        sequences: List of sequences
        features: DataFrame containing features
        clusters: Cluster labels
        network: NetworkX graph
        output_dir: Output directory for report
        
    Returns:
        Path to generated report
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    visualizer = GenomicVisualizer()
    
    # Create visualizations
    viz_dir = output_dir / "visualizations"
    viz_dir.mkdir(exist_ok=True)
    
    # Sequence length distribution
    visualizer.plot_sequence_length_distribution(
        sequences, save_path=viz_dir / "length_distribution.png")
    
    # GC content distribution
    visualizer.plot_gc_content_distribution(
        sequences, save_path=viz_dir / "gc_content_distribution.png")
    
    # Feature correlation heatmap
    visualizer.plot_feature_correlation_heatmap(
        features, save_path=viz_dir / "feature_correlation.png")
    
    # PCA analysis
    visualizer.plot_pca_analysis(
        features, labels=clusters, save_path=viz_dir / "pca_analysis.png")
    
    # Cluster analysis (if clusters provided)
    if clusters is not None:
        visualizer.plot_cluster_analysis(
            features, clusters, save_path=viz_dir / "cluster_analysis.png")
    
    # Network visualization (if network provided)
    if network is not None:
        visualizer.plot_network_visualization(
            network, save_path=viz_dir / "network_visualization.png")
    
    report_path = output_dir / "genomic_analysis_report.html"
    
    # Generate HTML report (simplified)
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>A-GENT Genomic Analysis Report</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; }}
            h1, h2 {{ color: #333; }}
            img {{ max-width: 100%; height: auto; margin: 20px 0; }}
        </style>
    </head>
    <body>
        <h1>A-GENT Genomic Analysis Report</h1>
        
        <h2>Dataset Overview</h2>
        <p>Total sequences: {len(sequences)}</p>
        <p>Total features: {len(features.columns)}</p>
        {f"<p>Number of clusters: {len(np.unique(clusters))}</p>" if clusters is not None else ""}
        {f"<p>Network nodes: {network.number_of_nodes()}</p>" if network is not None else ""}
        
        <h2>Sequence Length Distribution</h2>
        <img src="visualizations/length_distribution.png" alt="Length Distribution">
        
        <h2>GC Content Distribution</h2>
        <img src="visualizations/gc_content_distribution.png" alt="GC Content Distribution">
        
        <h2>Feature Analysis</h2>
        <img src="visualizations/feature_correlation.png" alt="Feature Correlation">
        <img src="visualizations/pca_analysis.png" alt="PCA Analysis">
        
        {f'<h2>Cluster Analysis</h2><img src="visualizations/cluster_analysis.png" alt="Cluster Analysis">' if clusters is not None else ""}
        
        {f'<h2>Network Analysis</h2><img src="visualizations/network_visualization.png" alt="Network Visualization">' if network is not None else ""}
        
    </body>
    </html>
    """
    
    with open(report_path, 'w') as f:
        f.write(html_content)
    
    print(f"Report generated: {report_path}")
    return str(report_path)


if __name__ == "__main__":
    # Example usage
    from sklearn.datasets import make_blobs
    
    # Create example data
    X, y = make_blobs(n_samples=200, centers=3, n_features=10, random_state=42)
    features_df = pd.DataFrame(X, columns=[f'feature_{i}' for i in range(X.shape[1])])
    
    # Create visualizer
    visualizer = GenomicVisualizer()
    
    # Example plots
    visualizer.plot_pca_analysis(features_df, labels=y)
    visualizer.plot_cluster_analysis(features_df, y)