"""
Data ingestion module for A-GENT.

Handles loading and preprocessing of various genomic file formats.
"""

import os
import gzip
from typing import List, Dict, Iterator, Optional, Union
from pathlib import Path
import pandas as pd
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord


class GenomicDataLoader:
    """Main class for loading genomic data from various file formats."""
    
    def __init__(self, data_dir: str = "data/raw"):
        """
        Initialize the genomic data loader.
        
        Args:
            data_dir: Directory containing raw genomic data files
        """
        self.data_dir = Path(data_dir)
        self.supported_formats = ['.fasta', '.fa', '.fastq', '.fq', '.txt']
        
    def load_fasta(self, file_path: Union[str, Path]) -> List[SeqRecord]:
        """
        Load sequences from a FASTA file.
        
        Args:
            file_path: Path to the FASTA file
            
        Returns:
            List of SeqRecord objects
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
            
        sequences = []
        
        # Handle compressed files
        if file_path.suffix in ['.gz', '.bz2']:
            if file_path.suffix == '.gz':
                with gzip.open(file_path, 'rt') as handle:
                    sequences = list(SeqIO.parse(handle, "fasta"))
            else:
                # For bz2 files
                import bz2
                with bz2.open(file_path, 'rt') as handle:
                    sequences = list(SeqIO.parse(handle, "fasta"))
        else:
            with open(file_path, 'r') as handle:
                sequences = list(SeqIO.parse(handle, "fasta"))
                
        return sequences
    
    def load_fastq(self, file_path: Union[str, Path]) -> List[SeqRecord]:
        """
        Load sequences from a FASTQ file.
        
        Args:
            file_path: Path to the FASTQ file
            
        Returns:
            List of SeqRecord objects
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
            
        sequences = []
        
        # Handle compressed files
        if file_path.suffix in ['.gz', '.bz2']:
            if file_path.suffix == '.gz':
                with gzip.open(file_path, 'rt') as handle:
                    sequences = list(SeqIO.parse(handle, "fastq"))
            else:
                import bz2
                with bz2.open(file_path, 'rt') as handle:
                    sequences = list(SeqIO.parse(handle, "fastq"))
        else:
            with open(file_path, 'r') as handle:
                sequences = list(SeqIO.parse(handle, "fastq"))
                
        return sequences
    
    def auto_detect_format(self, file_path: Union[str, Path]) -> str:
        """
        Automatically detect the file format based on extension and content.
        
        Args:
            file_path: Path to the file
            
        Returns:
            Detected format string
        """
        file_path = Path(file_path)
        
        # Check extension
        if file_path.suffix.lower() in ['.fasta', '.fa']:
            return 'fasta'
        elif file_path.suffix.lower() in ['.fastq', '.fq']:
            return 'fastq'
        
        # If compressed, check the previous extension
        if file_path.suffix.lower() in ['.gz', '.bz2']:
            stem = file_path.stem
            if stem.endswith(('.fasta', '.fa')):
                return 'fasta'
            elif stem.endswith(('.fastq', '.fq')):
                return 'fastq'
        
        # Try to detect from content
        try:
            with open(file_path, 'r') as f:
                first_line = f.readline().strip()
                if first_line.startswith('>'):
                    return 'fasta'
                elif first_line.startswith('@'):
                    return 'fastq'
        except:
            pass
            
        return 'unknown'
    
    def load_sequences(self, file_path: Union[str, Path], 
                      format: Optional[str] = None) -> List[SeqRecord]:
        """
        Load sequences from a file with automatic format detection.
        
        Args:
            file_path: Path to the sequence file
            format: File format (if None, will auto-detect)
            
        Returns:
            List of SeqRecord objects
        """
        if format is None:
            format = self.auto_detect_format(file_path)
            
        if format == 'fasta':
            return self.load_fasta(file_path)
        elif format == 'fastq':
            return self.load_fastq(file_path)
        else:
            raise ValueError(f"Unsupported format: {format}")
    
    def batch_load(self, pattern: str = "*.fasta") -> Dict[str, List[SeqRecord]]:
        """
        Load multiple files matching a pattern.
        
        Args:
            pattern: File pattern to match
            
        Returns:
            Dictionary mapping filenames to sequence lists
        """
        results = {}
        
        for file_path in self.data_dir.glob(pattern):
            try:
                sequences = self.load_sequences(file_path)
                results[file_path.name] = sequences
            except Exception as e:
                print(f"Error loading {file_path}: {e}")
                
        return results
    
    def get_sequence_stats(self, sequences: List[SeqRecord]) -> Dict:
        """
        Calculate basic statistics for a list of sequences.
        
        Args:
            sequences: List of SeqRecord objects
            
        Returns:
            Dictionary containing sequence statistics
        """
        if not sequences:
            return {}
            
        lengths = [len(seq) for seq in sequences]
        
        stats = {
            'total_sequences': len(sequences),
            'total_length': sum(lengths),
            'average_length': sum(lengths) / len(lengths),
            'min_length': min(lengths),
            'max_length': max(lengths),
            'median_length': sorted(lengths)[len(lengths) // 2]
        }
        
        return stats


def load_genomic_data(file_path: Union[str, Path], 
                     format: Optional[str] = None) -> List[SeqRecord]:
    """
    Convenience function to load genomic data.
    
    Args:
        file_path: Path to the genomic data file
        format: File format (optional, will auto-detect)
        
    Returns:
        List of SeqRecord objects
    """
    loader = GenomicDataLoader()
    return loader.load_sequences(file_path, format)


def load_metadata(file_path: Union[str, Path]) -> pd.DataFrame:
    """
    Load metadata from a CSV or TSV file.
    
    Args:
        file_path: Path to the metadata file
        
    Returns:
        DataFrame containing metadata
    """
    file_path = Path(file_path)
    
    if file_path.suffix.lower() == '.csv':
        return pd.read_csv(file_path)
    elif file_path.suffix.lower() in ['.tsv', '.txt']:
        return pd.read_csv(file_path, sep='\t')
    else:
        raise ValueError(f"Unsupported metadata format: {file_path.suffix}")


if __name__ == "__main__":
    # Example usage
    loader = GenomicDataLoader()
    
    # Load a single file
    try:
        sequences = loader.load_sequences("data/raw/example.fasta")
        print(f"Loaded {len(sequences)} sequences")
        
        # Get statistics
        stats = loader.get_sequence_stats(sequences)
        print("Sequence statistics:", stats)
        
    except FileNotFoundError:
        print("Example file not found. Please add genomic data to data/raw/")