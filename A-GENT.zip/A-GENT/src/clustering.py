"""
Clustering module for A-GENT.

Implements various clustering algorithms for genomic sequence analysis.
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional, Union, Any
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering, SpectralClustering
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.decomposition import PCA, TSNE
from sklearn.metrics import silhouette_score, adjusted_rand_score, normalized_mutual_info_score
from sklearn.neighbors import NearestNeighbors
import matplotlib.pyplot as plt
import seaborn as sns


class SequenceClusterer:
    """Main class for clustering genomic sequences based on extracted features."""
    
    def __init__(self, random_state: int = 42):
        """
        Initialize the sequence clusterer.
        
        Args:
            random_state: Random state for reproducibility
        """
        self.random_state = random_state
        self.scaler = None
        self.clusterer = None
        self.features = None
        self.labels = None
        self.cluster_centers = None
        
    def preprocess_features(self, features: pd.DataFrame, 
                           scaling_method: str = 'standard') -> pd.DataFrame:
        """
        Preprocess features for clustering.
        
        Args:
            features: DataFrame containing sequence features
            scaling_method: Scaling method ('standard', 'minmax', or 'none')
            
        Returns:
            Preprocessed features DataFrame
        """
        # Remove non-numeric columns
        numeric_features = features.select_dtypes(include=[np.number])
        
        # Handle missing values
        numeric_features = numeric_features.fillna(numeric_features.mean())
        
        # Handle infinite values
        numeric_features = numeric_features.replace([np.inf, -np.inf], np.nan)
        numeric_features = numeric_features.fillna(numeric_features.mean())
        
        # Scale features
        if scaling_method == 'standard':
            self.scaler = StandardScaler()
            scaled_features = self.scaler.fit_transform(numeric_features)
        elif scaling_method == 'minmax':
            self.scaler = MinMaxScaler()
            scaled_features = self.scaler.fit_transform(numeric_features)
        else:
            scaled_features = numeric_features.values
            
        self.features = pd.DataFrame(scaled_features, 
                                   columns=numeric_features.columns,
                                   index=numeric_features.index)
        
        return self.features
    
    def kmeans_clustering(self, n_clusters: int, **kwargs) -> np.ndarray:
        """
        Perform K-means clustering.
        
        Args:
            n_clusters: Number of clusters
            **kwargs: Additional parameters for KMeans
            
        Returns:
            Array of cluster labels
        """
        if self.features is None:
            raise ValueError("Features must be preprocessed first")
            
        self.clusterer = KMeans(n_clusters=n_clusters, 
                               random_state=self.random_state, 
                               **kwargs)
        self.labels = self.clusterer.fit_predict(self.features)
        self.cluster_centers = self.clusterer.cluster_centers_
        
        return self.labels
    
    def dbscan_clustering(self, eps: float = 0.5, min_samples: int = 5, 
                         **kwargs) -> np.ndarray:
        """
        Perform DBSCAN clustering.
        
        Args:
            eps: Maximum distance between samples in a neighborhood
            min_samples: Minimum number of samples in a neighborhood
            **kwargs: Additional parameters for DBSCAN
            
        Returns:
            Array of cluster labels
        """
        if self.features is None:
            raise ValueError("Features must be preprocessed first")
            
        self.clusterer = DBSCAN(eps=eps, min_samples=min_samples, **kwargs)
        self.labels = self.clusterer.fit_predict(self.features)
        
        return self.labels
    
    def hierarchical_clustering(self, n_clusters: int, 
                              linkage: str = 'ward', **kwargs) -> np.ndarray:
        """
        Perform hierarchical clustering.
        
        Args:
            n_clusters: Number of clusters
            linkage: Linkage criterion
            **kwargs: Additional parameters for AgglomerativeClustering
            
        Returns:
            Array of cluster labels
        """
        if self.features is None:
            raise ValueError("Features must be preprocessed first")
            
        self.clusterer = AgglomerativeClustering(n_clusters=n_clusters,
                                               linkage=linkage,
                                               **kwargs)
        self.labels = self.clusterer.fit_predict(self.features)
        
        return self.labels
    
    def gaussian_mixture_clustering(self, n_components: int, 
                                  **kwargs) -> np.ndarray:
        """
        Perform Gaussian Mixture Model clustering.
        
        Args:
            n_components: Number of mixture components
            **kwargs: Additional parameters for GaussianMixture
            
        Returns:
            Array of cluster labels
        """
        if self.features is None:
            raise ValueError("Features must be preprocessed first")
            
        self.clusterer = GaussianMixture(n_components=n_components,
                                       random_state=self.random_state,
                                       **kwargs)
        self.clusterer.fit(self.features)
        self.labels = self.clusterer.predict(self.features)
        
        return self.labels
    
    def spectral_clustering(self, n_clusters: int, **kwargs) -> np.ndarray:
        """
        Perform spectral clustering.
        
        Args:
            n_clusters: Number of clusters
            **kwargs: Additional parameters for SpectralClustering
            
        Returns:
            Array of cluster labels
        """
        if self.features is None:
            raise ValueError("Features must be preprocessed first")
            
        self.clusterer = SpectralClustering(n_clusters=n_clusters,
                                          random_state=self.random_state,
                                          **kwargs)
        self.labels = self.clusterer.fit_predict(self.features)
        
        return self.labels
    
    def auto_select_clusters(self, max_clusters: int = 10, 
                           method: str = 'elbow') -> int:
        """
        Automatically select the optimal number of clusters.
        
        Args:
            max_clusters: Maximum number of clusters to test
            method: Method for selection ('elbow', 'silhouette')
            
        Returns:
            Optimal number of clusters
        """
        if self.features is None:
            raise ValueError("Features must be preprocessed first")
            
        scores = []
        cluster_range = range(2, max_clusters + 1)
        
        for n_clusters in cluster_range:
            if method == 'elbow':
                kmeans = KMeans(n_clusters=n_clusters, 
                              random_state=self.random_state)
                kmeans.fit(self.features)
                scores.append(kmeans.inertia_)
            elif method == 'silhouette':
                kmeans = KMeans(n_clusters=n_clusters, 
                              random_state=self.random_state)
                labels = kmeans.fit_predict(self.features)
                score = silhouette_score(self.features, labels)
                scores.append(score)
        
        if method == 'elbow':
            # Find elbow point (simplified)
            diffs = np.diff(scores)
            diffs2 = np.diff(diffs)
            elbow_idx = np.argmax(diffs2) + 2  # +2 because of double diff and 0-indexing
            optimal_clusters = cluster_range[elbow_idx]
        elif method == 'silhouette':
            optimal_clusters = cluster_range[np.argmax(scores)]
        
        return optimal_clusters
    
    def evaluate_clustering(self, true_labels: Optional[np.ndarray] = None) -> Dict:
        """
        Evaluate clustering performance.
        
        Args:
            true_labels: True cluster labels (if available)
            
        Returns:
            Dictionary containing evaluation metrics
        """
        if self.labels is None:
            raise ValueError("No clustering results available")
            
        metrics = {}
        
        # Internal metrics
        if len(set(self.labels)) > 1:  # More than one cluster
            metrics['silhouette_score'] = silhouette_score(self.features, self.labels)
            
        metrics['n_clusters'] = len(set(self.labels))
        metrics['n_noise_points'] = list(self.labels).count(-1) if -1 in self.labels else 0
        
        # External metrics (if true labels available)
        if true_labels is not None:
            metrics['adjusted_rand_score'] = adjusted_rand_score(true_labels, self.labels)
            metrics['normalized_mutual_info'] = normalized_mutual_info_score(true_labels, self.labels)
        
        return metrics
    
    def get_cluster_summary(self) -> pd.DataFrame:
        """
        Get summary statistics for each cluster.
        
        Returns:
            DataFrame containing cluster summaries
        """
        if self.labels is None or self.features is None:
            raise ValueError("No clustering results available")
            
        cluster_summary = []
        
        for cluster_id in sorted(set(self.labels)):
            if cluster_id == -1:  # Skip noise points
                continue
                
            cluster_mask = self.labels == cluster_id
            cluster_features = self.features[cluster_mask]
            
            summary = {
                'cluster_id': cluster_id,
                'size': cluster_mask.sum(),
                'mean_features': cluster_features.mean(),
                'std_features': cluster_features.std()
            }
            
            cluster_summary.append(summary)
        
        return pd.DataFrame(cluster_summary)
    
    def dimensionality_reduction(self, method: str = 'pca', 
                               n_components: int = 2) -> np.ndarray:
        """
        Perform dimensionality reduction for visualization.
        
        Args:
            method: Reduction method ('pca' or 'tsne')
            n_components: Number of components
            
        Returns:
            Reduced feature array
        """
        if self.features is None:
            raise ValueError("Features must be preprocessed first")
            
        if method == 'pca':
            reducer = PCA(n_components=n_components, random_state=self.random_state)
        elif method == 'tsne':
            reducer = TSNE(n_components=n_components, random_state=self.random_state)
        else:
            raise ValueError(f"Unsupported method: {method}")
        
        reduced_features = reducer.fit_transform(self.features)
        return reduced_features
    
    def plot_clusters(self, method: str = 'pca', figsize: Tuple[int, int] = (10, 8)):
        """
        Plot clusters in reduced dimensional space.
        
        Args:
            method: Dimensionality reduction method
            figsize: Figure size
        """
        if self.labels is None:
            raise ValueError("No clustering results available")
            
        # Reduce dimensions
        reduced_features = self.dimensionality_reduction(method=method, n_components=2)
        
        # Create plot
        plt.figure(figsize=figsize)
        
        # Plot each cluster
        unique_labels = set(self.labels)
        colors = plt.cm.tab10(np.linspace(0, 1, len(unique_labels)))
        
        for label, color in zip(unique_labels, colors):
            if label == -1:
                # Noise points
                cluster_mask = self.labels == label
                plt.scatter(reduced_features[cluster_mask, 0], 
                          reduced_features[cluster_mask, 1],
                          c='black', marker='x', s=50, alpha=0.6, label='Noise')
            else:
                cluster_mask = self.labels == label
                plt.scatter(reduced_features[cluster_mask, 0], 
                          reduced_features[cluster_mask, 1],
                          c=[color], s=50, alpha=0.6, label=f'Cluster {label}')
        
        plt.xlabel(f'{method.upper()} Component 1')
        plt.ylabel(f'{method.upper()} Component 2')
        plt.title('Sequence Clusters')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()


def cluster_sequences(features: pd.DataFrame, 
                     method: str = 'kmeans',
                     n_clusters: Optional[int] = None,
                     **kwargs) -> Tuple[np.ndarray, SequenceClusterer]:
    """
    Convenience function to cluster sequences.
    
    Args:
        features: DataFrame containing sequence features
        method: Clustering method
        n_clusters: Number of clusters (if applicable)
        **kwargs: Additional parameters for clustering
        
    Returns:
        Tuple of (cluster labels, clusterer object)
    """
    clusterer = SequenceClusterer()
    
    # Preprocess features
    clusterer.preprocess_features(features)
    
    # Auto-select clusters if not provided
    if n_clusters is None and method in ['kmeans', 'hierarchical', 'gaussian_mixture', 'spectral']:
        n_clusters = clusterer.auto_select_clusters()
        print(f"Auto-selected {n_clusters} clusters")
    
    # Perform clustering
    if method == 'kmeans':
        labels = clusterer.kmeans_clustering(n_clusters, **kwargs)
    elif method == 'dbscan':
        labels = clusterer.dbscan_clustering(**kwargs)
    elif method == 'hierarchical':
        labels = clusterer.hierarchical_clustering(n_clusters, **kwargs)
    elif method == 'gaussian_mixture':
        labels = clusterer.gaussian_mixture_clustering(n_clusters, **kwargs)
    elif method == 'spectral':
        labels = clusterer.spectral_clustering(n_clusters, **kwargs)
    else:
        raise ValueError(f"Unsupported clustering method: {method}")
    
    return labels, clusterer


if __name__ == "__main__":
    # Example usage
    from sklearn.datasets import make_blobs
    
    # Create example data
    X, y_true = make_blobs(n_samples=300, centers=4, n_features=20, 
                          random_state=42, cluster_std=0.60)
    
    features_df = pd.DataFrame(X, columns=[f'feature_{i}' for i in range(X.shape[1])])
    
    # Perform clustering
    labels, clusterer = cluster_sequences(features_df, method='kmeans')
    
    # Evaluate results
    metrics = clusterer.evaluate_clustering(y_true)
    print("Clustering metrics:", metrics)
    
    # Plot results
    clusterer.plot_clusters()